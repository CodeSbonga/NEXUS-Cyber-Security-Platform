/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'f-bg':     '#0d0d10',
        'f-soft':   '#111114',
        'f-text':   '#f2f2f4',
        'f-dim':    'rgba(242,242,244,0.38)',
        'f-faint':  'rgba(242,242,244,0.16)',
        'f-border': 'rgba(255,255,255,0.07)',
        'f-sev-r':  '#e05c5c',
        'f-sev-a':  '#d4884a',
        'f-sev-y':  '#c4b448',
        'f-sev-g':  '#52a882',
      },
      fontFamily: {
        syne:  ['Syne', 'sans-serif'],
        sans:  ['DM Sans', 'sans-serif'],
        mono:  ['DM Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
