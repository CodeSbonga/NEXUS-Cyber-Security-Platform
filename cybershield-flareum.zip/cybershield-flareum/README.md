# CyberShield + NEXUS — Flareum Redesign

A hyperrealistic Flareum-aesthetic redesign of the CyberShield + NEXUS platform.
Pitch-black background, massive white typography, ultra-minimal luxury with immersive 3D depth.

---

## Quick Start

```bash
npm install
npm run dev
# → http://localhost:3000
```

---

## Design System — Flareum Aesthetic

### Colour palette
| Token       | Value                   | Usage                    |
|-------------|-------------------------|--------------------------|
| `--bg`      | `#0d0d10`               | Page background          |
| `--text`    | `#f2f2f4`               | Primary text             |
| `--text-dim`| `rgba(242,242,244,0.38)`| Secondary text           |
| `--border`  | `rgba(255,255,255,0.07)`| Dividers, borders        |
| `--red`     | `#e05c5c`               | Critical / danger        |
| `--amber`   | `#d4884a`               | High severity            |
| `--green`   | `#52a882`               | Success / active         |

### Typography
| Font        | Role             | Weight     |
|-------------|------------------|------------|
| **Syne**    | Display headings | 700–800    |
| **DM Sans** | Body / UI text   | 200–400    |
| **DM Mono** | Data / labels    | 300–500    |

### Key CSS classes
```css
.f-display        /* Giant Syne display heading */
.f-label          /* DM Mono 10px uppercase label */
.f-mono           /* DM Mono 11px data text */
.glass            /* Subtle glassmorphism panel */
.glass-md         /* Stronger glass for modals */
.math-grid        /* 72px precision grid overlay */
.math-grid-fine   /* 24px fine grid overlay */
.grain            /* Film grain animation overlay */
.f-btn-primary    /* White pill button */
.f-btn-ghost      /* Ghost border pill button */
.pulse-dot        /* Animated green status dot */
.f-divider        /* Gradient horizontal divider */
.corner-tl        /* Top-left corner bracket accent */
.corner-br        /* Bottom-right corner bracket accent */
.f-progress-bg    /* Thin progress track */
.f-progress-fill  /* Animated progress fill */
```

---

## Pages

| Route        | 3D Scene           | Content                          |
|--------------|--------------------|----------------------------------|
| `/`          | FlareScene         | Hero, stats strip, features grid |
| `/nexus`     | FlareNetGraph      | Live threat feed, AI analysis    |
| `/shield`    | FlareTunnel        | Mission cards + briefing modal   |
| `/threats`   | FlareGlobe         | Global attack map + live stream  |
| `/analytics` | FlareScene (dim)   | KPI strip, bar chart, breakdowns |

---

## 3D Components

All in `src/components/3d/`:

- **FlareScene** — Main landing scene: floating icosahedron with orbital tori, drifting particles, mouse-reactive floor grid
- **FlareNetGraph** — Threat network: white/silver nodes + animated connection lines, auto-rotating with OrbitControls
- **FlareTunnel** — Mission page: scrolling ring tunnel, floating hexagonal data fragments
- **FlareGlobe** — Earth globe with wireframe shell, attack arcs, equatorial ring
- **CyberConstruction** — Original city construction scene (still available)

### Flareum 3D philosophy
- No colour — everything is white, silver, or near-black
- Geometry > texture; prefer wireframes and thin edges
- Subtle opacity and emissive intensity, never saturated colours
- Mouse parallax on the main scene — depth without exaggeration
- Minimal post-processing; let the geometry speak

---

## Extending

### Add bloom / glow (optional)
```bash
npm install @react-three/postprocessing
```
```tsx
import { EffectComposer, Bloom } from '@react-three/postprocessing'
<EffectComposer>
  <Bloom intensity={0.4} luminanceThreshold={0.9} radius={0.8} />
</EffectComposer>
```

### Add a new page
1. Create `src/app/your-page/page.tsx`
2. Add to `LINKS` in `FlareNav.tsx`
3. Transitions are automatic via `FlareTransition`

---

## Credits
Design system language inspired by [Flareum.io](https://flareum.io) by The Glyph Studio.
