'use client'

import { useRef, useMemo, useEffect, useState, useCallback } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Float, PerspectiveCamera } from '@react-three/drei'
import * as THREE from 'three'

// ---------- Building Block ----------
interface BuildingBlock {
  position: [number, number, number]
  size: [number, number, number]
  color: string
  emissive: string
  emissiveIntensity: number
  wireframe?: boolean
  opacity?: number
  delay: number
}

function BuildingUnit({
  block,
  progress,
  hovered,
}: {
  block: BuildingBlock
  progress: number
  hovered: boolean
}) {
  const meshRef = useRef<THREE.Mesh>(null)
  const localProgress = Math.max(0, Math.min(1, (progress - block.delay) / 0.3))

  useFrame((state) => {
    if (meshRef.current) {
      const scaleY = Math.max(0.001, localProgress)
      meshRef.current.scale.y = scaleY
      const halfH = (block.size[1] * scaleY) / 2
      meshRef.current.position.y = block.position[1] - block.size[1] / 2 + halfH

      // Pulse glow
      if (block.emissiveIntensity > 0.3) {
        const mat = meshRef.current.material as THREE.MeshStandardMaterial
        mat.emissiveIntensity = block.emissiveIntensity + Math.sin(state.clock.elapsedTime * 2) * 0.2
      }
    }
  })

  if (localProgress <= 0) return null

  return (
    <mesh
      ref={meshRef}
      position={[block.position[0], block.position[1] - block.size[1] / 2, block.position[2]]}
    >
      <boxGeometry args={block.size} />
      <meshStandardMaterial
        color={block.color}
        emissive={hovered ? '#ffffff' : block.emissive}
        emissiveIntensity={hovered ? 0.8 : block.emissiveIntensity}
        transparent
        opacity={block.opacity ?? Math.min(0.7, localProgress + 0.2)}
        wireframe={block.wireframe}
        roughness={0.3}
        metalness={0.8}
      />
    </mesh>
  )
}

// ---------- Light Beam ----------
function LightBeam({ y, color }: { y: number; color: string }) {
  const beamRef = useRef<THREE.Mesh>(null)
  useFrame(() => {
    if (beamRef.current) {
      beamRef.current.scale.x = 0.5 + Math.sin(Date.now() * 0.01 + y * 0.5) * 0.3
    }
  })
  return (
    <mesh ref={beamRef} position={[0, y, 0]}>
      <planeGeometry args={[0.4, 0.4]} />
      <meshBasicMaterial color={color} transparent opacity={0.8} />
    </mesh>
  )
}

// ---------- Scanner Ring ----------
function ScannerRing() {
  const ringRef = useRef<THREE.Mesh>(null)
  const ringRef2 = useRef<THREE.Mesh>(null)
  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.y = state.clock.elapsedTime * 0.8
      ringRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.1
    }
    if (ringRef2.current) {
      ringRef2.current.rotation.y = -state.clock.elapsedTime * 0.5
      ringRef2.current.rotation.x = Math.cos(state.clock.elapsedTime * 0.2) * 0.08
    }
  })
  return (
    <group position={[0, -2.5, 0]}>
      <mesh ref={ringRef}>
        <ringGeometry args={[3.8, 4.2, 100]} />
        <meshBasicMaterial color="#aaaaaa" transparent opacity={0.12} side={THREE.DoubleSide} />
      </mesh>
      <mesh ref={ringRef2}>
        <ringGeometry args={[4.4, 4.6, 80]} />
        <meshBasicMaterial color="#888888" transparent opacity={0.08} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

// ---------- Connection Lines ----------
function ConnectionLines() {
  const lines = useMemo(() => {
    const result: { points: [number, number, number][]; color: string }[] = []
    for (let i = 0; i < 24; i++) {
      const angle1 = (i / 24) * Math.PI * 2
      const r1 = 2.0 + Math.random() * 2.0
      const y1 = -2 + Math.random() * 5
      const angle2 = angle1 + (Math.random() - 0.5) * 0.8
      const r2 = 2.0 + Math.random() * 2.0
      const y2 = -2 + Math.random() * 5
      result.push({
        points: [
          [Math.cos(angle1) * r1, y1, Math.sin(angle1) * r1],
          [Math.cos(angle2) * r2, y2, Math.sin(angle2) * r2],
        ],
        color: [0, 0, 0].map(() => 0.7 + Math.random() * 0.3).join(','),
      })
    }
    return result
  }, [])

  const linesRef = useRef<THREE.Group>(null)
  useFrame((state) => {
    if (linesRef.current) {
      linesRef.current.children.forEach((child, i) => {
        const mat = (child as THREE.Line).material as THREE.LineBasicMaterial
        if (mat) mat.opacity = 0.08 + Math.sin(state.clock.elapsedTime * 1.5 + i * 0.5) * 0.06
      })
    }
  })

  return (
    <group ref={linesRef}>
      {lines.map((line, i) => (
        <line key={i}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              args={[new Float32Array(line.points.flat()), 3]}
            />
          </bufferGeometry>
          <lineBasicMaterial color="#999999" transparent opacity={0.12} />
        </line>
      ))}
    </group>
  )
}

// ---------- Floating Particles ----------
function FloatingParticles() {
  const count = 1500
  const ref = useRef<THREE.Points>(null)
  const velocities = useRef<Float32Array>()

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3)
    const vel = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      const radius = 1.0 + Math.random() * 5
      pos[i * 3] = Math.sin(phi) * Math.cos(theta) * radius
      pos[i * 3 + 1] = (Math.random() - 0.5) * 8
      pos[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * radius
      vel[i] = 0.002 + Math.random() * 0.008
    }
    velocities.current = vel
    return pos
  }, [])

  useFrame((state) => {
    if (ref.current) {
      const pos = ref.current.geometry.attributes.position.array as Float32Array
      for (let i = 0; i < count; i++) {
        pos[i * 3 + 1] += velocities.current![i]
        if (pos[i * 3 + 1] > 4) pos[i * 3 + 1] = -4
      }
      ref.current.geometry.attributes.position.needsUpdate = true
      ref.current.rotation.y = state.clock.elapsedTime * 0.015
    }
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#bbbbbb"
        size={0.04}
        transparent
        opacity={0.35}
        sizeAttenuation
      />
    </points>
  )
}

// ---------- Mouse Reactive Grid Floor ----------
function GridFloor() {
  const gridRef = useRef<THREE.GridHelper>(null)
  const { pointer } = useThree()

  useFrame(() => {
    if (gridRef.current) {
      gridRef.current.position.x = pointer.x * 2.0
      gridRef.current.position.z = pointer.y * 2.0
    }
  })

  return (
    <group>
      <gridHelper
        ref={gridRef}
        args={[16, 24, '#666666', '#333333']}
        position={[0, -3.2, 0]}
      />
      {/* Glowing floor ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.15, 0]}>
        <ringGeometry args={[0.5, 4.5, 80]} />
        <meshBasicMaterial color="#888888" transparent opacity={0.04} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

// ---------- Energy Orbs ----------
function EnergyOrbs() {
  const groupRef = useRef<THREE.Group>(null)
  const orbs = useMemo(() => {
    return Array.from({ length: 6 }, (_, i) => ({
      angle: (i / 6) * Math.PI * 2,
      radius: 2.2 + Math.random() * 0.5,
      yOff: (Math.random() - 0.5) * 3,
      speed: 0.2 + Math.random() * 0.3,
      size: 0.04 + Math.random() * 0.04,
    }))
  }, [])

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.children.forEach((child, i) => {
        const orb = orbs[i]
        if (orb) {
          const a = orb.angle + state.clock.elapsedTime * orb.speed
          child.position.x = Math.cos(a) * orb.radius
          child.position.z = Math.sin(a) * orb.radius
          child.position.y = orbs[i].yOff + Math.sin(state.clock.elapsedTime * 1.5 + i) * 0.3
        }
      })
    }
  })

  return (
    <group ref={groupRef}>
      {orbs.map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.04, 8, 8]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={0.6} />
        </mesh>
      ))}
    </group>
  )
}

// ---------- Main Scene ----------
function ConstructionScene({ mousePos, isFullSize }: { mousePos: { x: number; y: number }; isFullSize: boolean }) {
  const [progress, setProgress] = useState(0)
  const groupRef = useRef<THREE.Group>(null)

  const buildings: BuildingBlock[] = useMemo(() => {
    const b: BuildingBlock[] = []
    const mainColor = '#c0c0c0'
    const darkColor = '#666666'
    const lightColor = '#e8e8e8'
    const scale = isFullSize ? 1.3 : 1.0

    const s = (n: number) => n * scale
    const p = (x: number, y: number, z: number): [number, number, number] => [x * scale, y * scale, z * scale]

    // Central tower - base (wider)
    b.push({
      position: p(0, -1.5, 0), size: [s(1.2), s(3), s(1.2)],
      color: mainColor, emissive: '#888888', emissiveIntensity: 0.15, delay: 0,
    })
    // Central tower - mid
    b.push({
      position: p(0, 0, 0), size: [s(0.8), s(2), s(0.8)],
      color: lightColor, emissive: '#aaaaaa', emissiveIntensity: 0.25, delay: 0.3,
    })
    // Central tower - top
    b.push({
      position: p(0, 1.2, 0), size: [s(0.5), s(1.2), s(0.5)],
      color: '#ffffff', emissive: '#cccccc', emissiveIntensity: 0.4, delay: 0.6,
    })
    // Central spire
    b.push({
      position: p(0, 2.0, 0), size: [s(0.08), s(0.8), s(0.08)],
      color: '#ffffff', emissive: '#ffffff', emissiveIntensity: 0.8, delay: 0.8, wireframe: true,
    })

    // Inner ring structures
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2
      const r = s(1.8)
      b.push({
        position: p(Math.cos(angle) * r / scale, -1.0 + Math.sin(i * 1.5) * 0.3, Math.sin(angle) * r / scale),
        size: [s(0.3), s(0.7), s(0.3)],
        color: i % 2 === 0 ? mainColor : darkColor,
        emissive: '#777777',
        emissiveIntensity: 0.15,
        delay: 0.2 + i * 0.07,
      })
    }

    // Middle ring pillars (taller)
    for (let i = 0; i < 10; i++) {
      const angle = (i / 10) * Math.PI * 2
      const r = s(2.6)
      b.push({
        position: p(Math.cos(angle) * r / scale, -1.5 + Math.sin(i * 2) * 0.3, Math.sin(angle) * r / scale),
        size: [s(0.12), s(1.5 + Math.sin(i * 3) * 0.5), s(0.12)],
        color: darkColor,
        emissive: '#666666',
        emissiveIntensity: 0.08,
        delay: 0.5 + i * 0.05,
      })
    }

    // Outer ring pillars
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2
      const r = s(3.5)
      b.push({
        position: p(Math.cos(angle) * r / scale, -2.0 + Math.sin(i * 2) * 0.2, Math.sin(angle) * r / scale),
        size: [s(0.08), s(1.0 + Math.sin(i * 3) * 0.4), s(0.08)],
        color: darkColor,
        emissive: '#555555',
        emissiveIntensity: 0.05,
        delay: 0.7 + i * 0.04,
      })
    }

    // Cross beams
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2
      const midR = s(2.2)
      b.push({
        position: p(Math.cos(angle) * midR / scale, -1.0, Math.sin(angle) * midR / scale),
        size: [s(0.03), s(0.04), s(1.2)],
        color: lightColor,
        emissive: '#999999',
        emissiveIntensity: 0.15,
        delay: 0.9 + i * 0.04,
        opacity: 0.5,
      })
      b.push({
        position: p(Math.cos(angle + 0.25) * midR / scale, 0.2, Math.sin(angle + 0.25) * midR / scale),
        size: [s(1.0), s(0.03), s(0.04)],
        color: lightColor,
        emissive: '#999999',
        emissiveIntensity: 0.15,
        delay: 1.0 + i * 0.04,
        opacity: 0.5,
      })
    }

    // Floating data cubes (more)
    for (let i = 0; i < 30; i++) {
      const angle = Math.random() * Math.PI * 2
      const r = s(1.2 + Math.random() * 3.0)
      b.push({
        position: p(Math.cos(angle) * r / scale, -2 + Math.random() * 5.5, Math.sin(angle) * r / scale),
        size: [s(0.03), s(0.03), s(0.03)],
        color: '#ffffff',
        emissive: '#eeeeee',
        emissiveIntensity: 1.0,
        delay: 1.2 + Math.random() * 0.8,
        opacity: 0.9,
      })
    }

    return b
  }, [isFullSize])

  useEffect(() => {
    setProgress(0)
    const interval = setInterval(() => {
      setProgress((p) => Math.min(1, p + 0.006))
    }, 50)
    return () => clearInterval(interval)
  }, [])

  useFrame((state) => {
    if (groupRef.current) {
      const targetRotX = mousePos.y * 0.2
      const targetRotY = mousePos.x * 0.2
      groupRef.current.rotation.x += (targetRotX - groupRef.current.rotation.x) * 0.02
      groupRef.current.rotation.y += (targetRotY - groupRef.current.rotation.y) * 0.02

      if (Math.abs(mousePos.x) < 0.05 && Math.abs(mousePos.y) < 0.05) {
        groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.1
      }
    }
  })

  return (
    <group ref={groupRef}>
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 10, 5]} intensity={1.5} color="#ffffff" />
      <directionalLight position={[-5, 6, -5]} intensity={0.8} color="#aaaaaa" />
      <pointLight position={[0, 4, 0]} intensity={1.2} color="#dddddd" distance={10} />
      <pointLight position={[3, -1, 3]} intensity={0.5} color="#999999" distance={8} />
      <pointLight position={[-3, -1, -3]} intensity={0.5} color="#aaaaaa" distance={8} />

      <GridFloor />
      <ScannerRing />
      <ConnectionLines />
      <FloatingParticles />
      <EnergyOrbs />

      {buildings.map((block, i) => (
        <BuildingUnit
          key={i}
          block={block}
          progress={progress}
          hovered={false}
        />
      ))}

      {/* Central beam of light */}
      <mesh position={[0, -3, 0]}>
        <cylinderGeometry args={[0.03, 0.08, 7, 8]} />
        <meshBasicMaterial color="#aaaaaa" transparent opacity={0.08} />
      </mesh>

      {/* Vertical scanning light */}
      <LightBeam y={progress * 6 - 3} color="#ffffff" />
    </group>
  )
}

// ---------- Interactive overlay handler ----------
export default function CyberConstruction({ fullSize = false }: { fullSize?: boolean }) {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const [isInteracting, setIsInteracting] = useState(false)

  const handlePointerMove = useCallback((e: any) => {
    if (e.clientX) {
      setMousePos({
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: -(e.clientY / window.innerHeight) * 2 + 1,
      })
    }
  }, [])

  const handlePointerDown = useCallback(() => {
    setIsInteracting(true)
    setTimeout(() => setIsInteracting(false), 400)
  }, [])

  useEffect(() => {
    window.addEventListener('mousemove', handlePointerMove)
    window.addEventListener('mousedown', handlePointerDown)
    return () => {
      window.removeEventListener('mousemove', handlePointerMove)
      window.removeEventListener('mousedown', handlePointerDown)
    }
  }, [handlePointerMove, handlePointerDown])

  return (
    <div className="relative w-full h-full">
      <Canvas
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <PerspectiveCamera makeDefault position={[0, 1, 7]} fov={fullSize ? 50 : 45} />
        <ConstructionScene mousePos={mousePos} isFullSize={fullSize} />
      </Canvas>
      {isInteracting && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="w-full h-full bg-white/8 animate-pulse rounded-full" />
        </div>
      )}
    </div>
  )
}