'use client'
import { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera } from '@react-three/drei'
import * as THREE from 'three'

function Globe() {
  const ref = useRef<THREE.Mesh>(null)
  useFrame(s => { if (ref.current) ref.current.rotation.y = s.clock.elapsedTime * 0.07 })
  return (
    <group>
      {/* Core sphere */}
      <mesh ref={ref}>
        <sphereGeometry args={[2.4,64,64]} />
        <meshStandardMaterial color="#0f0f14" metalness={0.5} roughness={0.6}
          emissive="#111118" emissiveIntensity={0.4} />
      </mesh>
      {/* Wireframe shell */}
      <mesh ref={ref}>
        <sphereGeometry args={[2.42,28,28]} />
        <meshStandardMaterial color="#ffffff" wireframe transparent opacity={0.055} />
      </mesh>
      {/* Atmosphere */}
      <mesh>
        <sphereGeometry args={[2.62,32,32]} />
        <meshStandardMaterial color="#8888aa" transparent opacity={0.025} side={THREE.BackSide} />
      </mesh>
    </group>
  )
}

function AttackArcs() {
  const ref = useRef<THREE.Group>(null)
  const arcs = useMemo(() => {
    const pairs = [
      { a:[0.7,0.5,-2.3], b:[-1.4,0.8,-1.9] },
      { a:[1.1,1.0,-2.1], b:[-0.3,-0.5,-2.3] },
      { a:[-0.4,1.3,-2.1],b:[1.7,-0.2,-1.7]  },
      { a:[-1.7,0.3,-1.7],b:[0.7,0.3,-2.3]   },
      { a:[0.9,-1.1,-2.2],b:[-0.7,0.5,-2.3]  },
    ]
    return pairs.map((p,i) => {
      const s = new THREE.Vector3(...p.a as [number,number,number])
      const e = new THREE.Vector3(...p.b as [number,number,number])
      const m = s.clone().lerp(e,0.5).normalize().multiplyScalar(3.4)
      const curve = new THREE.QuadraticBezierCurve3(s,m,e)
      return { geo: new THREE.BufferGeometry().setFromPoints(curve.getPoints(48)),
               col: i < 2 ? '#e05c5c' : '#d4884a' }
    })
  }, [])

  useFrame(s => {
    ref.current?.children.forEach((c,i) => {
      const m = (c as THREE.Line).material as THREE.LineBasicMaterial
      if (m) m.opacity = Math.abs(Math.sin(s.clock.elapsedTime*1.4+i*0.9)) * 0.7
    })
  })

  return (
    <group ref={ref}>
      {arcs.map((a,i) => (
        <line key={i} geometry={a.geo}>
          <lineBasicMaterial color={a.col} transparent opacity={0.5} />
        </line>
      ))}
    </group>
  )
}

function HotNodes() {
  const ref = useRef<THREE.Group>(null)
  useFrame(s => { if (ref.current) ref.current.rotation.y = s.clock.elapsedTime*0.07 })
  const pts = [
    [[0.7,0.5,-2.45],'#e05c5c'], [[-1.4,0.8,-2.0],'#e05c5c'],
    [[1.1,1.0,-2.2],'#d4884a'],  [[-0.4,1.3,-2.1],'#ffffff'],
    [[1.7,-0.2,-1.7],'#d4884a'], [[-1.7,0.3,-1.7],'#e05c5c'],
  ]
  return (
    <group ref={ref}>
      {pts.map(([pos,col],i) => (
        <mesh key={i} position={pos as [number,number,number]}>
          <sphereGeometry args={[0.055,10,10]} />
          <meshStandardMaterial color={col as string} emissive={col as string} emissiveIntensity={3} />
        </mesh>
      ))}
    </group>
  )
}

function EqRing() {
  const ref = useRef<THREE.Mesh>(null)
  useFrame(s => { if (ref.current) ref.current.rotation.z = s.clock.elapsedTime*0.09 })
  return (
    <mesh ref={ref} rotation={[Math.PI/2,0,0]}>
      <torusGeometry args={[3.1,0.007,6,220]} />
      <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={1}
        transparent opacity={0.3} />
    </mesh>
  )
}

export default function FlareGlobe() {
  return (
    <Canvas gl={{ antialias:true, alpha:true }} style={{ background:'transparent' }}>
      <PerspectiveCamera makeDefault position={[0,2,7]} fov={46} />
      <ambientLight intensity={0.1} />
      <pointLight position={[4,4,4]} color="#ffffff" intensity={2} distance={20} />
      <pointLight position={[-4,-4,-4]} color="#8888aa" intensity={0.8} distance={20} />
      <Globe />
      <AttackArcs />
      <HotNodes />
      <EqRing />
      <OrbitControls enableZoom autoRotate autoRotateSpeed={0.28} maxDistance={14} minDistance={4} />
    </Canvas>
  )
}
