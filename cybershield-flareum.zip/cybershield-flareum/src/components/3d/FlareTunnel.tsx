'use client'
import { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { PerspectiveCamera, Float } from '@react-three/drei'
import * as THREE from 'three'

function Tunnel() {
  const g = useRef<THREE.Group>(null)
  const rings = useMemo(() =>
    Array.from({ length: 28 }, (_, i) => ({
      z: -i * 2.8,
      r: 3.8 + Math.sin(i * 0.4) * 0.4,
      twist: (i * Math.PI) / 10,
    })), []
  )

  useFrame(s => {
    if (g.current) g.current.position.z = (s.clock.elapsedTime * 0.7) % 2.8
  })

  return (
    <group ref={g}>
      {rings.map((ring,i) => (
        <mesh key={i} position={[0,0,ring.z]} rotation={[0,0,ring.twist]}>
          <torusGeometry args={[ring.r, 0.012, 6, 96]} />
          <meshStandardMaterial color={i%7===0?'#ffffff':'#444448'}
            emissive={i%7===0?'#ffffff':'#333336'}
            emissiveIntensity={i%7===0 ? 1.2 : 0.3}
            transparent opacity={0.25 - i*0.006} />
        </mesh>
      ))}
    </group>
  )
}

function FloatingData() {
  const items = useMemo(() =>
    Array.from({ length: 14 }, (_, i) => ({
      pos: [(Math.random()-0.5)*16,(Math.random()-0.5)*8,(Math.random()-0.5)*8-4] as [number,number,number],
      rot: [Math.random()*Math.PI, Math.random()*Math.PI, 0] as [number,number,number],
      s: 0.25 + Math.random() * 0.6,
      white: Math.random() > 0.7,
    })), []
  )
  return (
    <>
      {items.map((it,i) => (
        <Float key={i} speed={0.8+Math.random()} floatIntensity={0.4} rotationIntensity={0.2}>
          <mesh position={it.pos} rotation={it.rot} scale={it.s}>
            <cylinderGeometry args={[0.5,0.5,0.06,6]} />
            <meshStandardMaterial color={it.white?'#ffffff':'#555558'}
              emissive={it.white?'#ffffff':'#444447'}
              emissiveIntensity={it.white?0.5:0.1}
              transparent opacity={0.15} wireframe />
          </mesh>
        </Float>
      ))}
    </>
  )
}

export default function FlareTunnel() {
  return (
    <Canvas gl={{ antialias:true, alpha:true }} style={{ background:'transparent' }}>
      <PerspectiveCamera makeDefault position={[0,0,10]} fov={68} />
      <fog attach="fog" args={['#0d0d10', 18, 55]} />
      <ambientLight intensity={0.08} />
      <pointLight position={[0,4,0]} color="#ffffff" intensity={2.5} distance={30} />
      <pointLight position={[0,-4,-8]} color="#aaaacc" intensity={1.2} distance={28} />
      <Tunnel />
      <FloatingData />
    </Canvas>
  )
}
