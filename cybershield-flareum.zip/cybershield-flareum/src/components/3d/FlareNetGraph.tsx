'use client'
import { useRef, useMemo, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera } from '@react-three/drei'
import * as THREE from 'three'

interface Node { id:number; pos:[number,number,number]; type:'hub'|'endpoint'|'threat'; conns:number[] }

function NetNode({ node, onHov }: { node:Node; onHov:(id:number|null)=>void }) {
  const ref = useRef<THREE.Mesh>(null)
  const [hov, setHov] = useState(false)
  const col = node.type==='threat' ? '#e05c5c' : node.type==='hub' ? '#f2f2f4' : '#888899'
  const sz  = node.type==='hub' ? 0.16 : node.type==='threat' ? 0.13 : 0.09

  useFrame(s => {
    if (ref.current && node.type==='threat') {
      ref.current.scale.setScalar(1 + Math.sin(s.clock.elapsedTime*3)*0.18)
    }
  })

  return (
    <mesh ref={ref} position={node.pos}
      onPointerEnter={e => { e.stopPropagation(); setHov(true); onHov(node.id) }}
      onPointerLeave={() => { setHov(false); onHov(null) }}>
      <sphereGeometry args={[hov ? sz*1.5 : sz, 16, 16]} />
      <meshStandardMaterial color={col} emissive={col}
        emissiveIntensity={hov ? 3 : node.type==='threat' ? 1.8 : 0.6}
        metalness={0.6} roughness={0.3} />
    </mesh>
  )
}

function Connections({ nodes }: { nodes: Node[] }) {
  const ref = useRef<THREE.Group>(null)
  const segs = useMemo(() => {
    const r: { geo: THREE.BufferGeometry; threat: boolean }[] = []
    nodes.forEach(n => n.conns.forEach(cid => {
      if (cid > n.id) {
        const t = nodes.find(x => x.id===cid)
        if (!t) return
        const threat = n.type==='threat' || t.type==='threat'
        r.push({ geo: new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(...n.pos), new THREE.Vector3(...t.pos)
        ]), threat })
      }
    }))
    return r
  }, [nodes])

  useFrame(s => {
    ref.current?.children.forEach((c,i) => {
      const m = (c as THREE.Line).material as THREE.LineBasicMaterial
      if (m) m.opacity = 0.1 + Math.sin(s.clock.elapsedTime*1.8+i*0.6)*0.07
    })
  })

  return (
    <group ref={ref}>
      {segs.map((seg,i) => (
        <line key={i} geometry={seg.geo}>
          <lineBasicMaterial color={seg.threat ? '#e05c5c' : '#aaaaaa'} transparent opacity={0.15} />
        </line>
      ))}
    </group>
  )
}

function Scene() {
  const [hov, setHov] = useState<number|null>(null)
  const nodes: Node[] = useMemo(() => [
    { id:0,  pos:[0,0,0],      type:'hub',      conns:[1,2,3,4,5] },
    { id:1,  pos:[4,1,-2],     type:'hub',      conns:[0,6,7,8]   },
    { id:2,  pos:[-4,-1,-1],   type:'hub',      conns:[0,9,10]    },
    { id:3,  pos:[2,-3,2],     type:'hub',      conns:[0,11,12]   },
    { id:4,  pos:[-3,3,1],     type:'hub',      conns:[0,13]      },
    { id:5,  pos:[1,2,-4],     type:'hub',      conns:[0,14,15]   },
    { id:6,  pos:[6,2,-3],     type:'endpoint', conns:[1]         },
    { id:7,  pos:[5,-1,-4],    type:'threat',   conns:[1,8]       },
    { id:8,  pos:[7,1,-1],     type:'endpoint', conns:[1,7]       },
    { id:9,  pos:[-6,0,-2],    type:'endpoint', conns:[2]         },
    { id:10, pos:[-5,-2,1],    type:'threat',   conns:[2]         },
    { id:11, pos:[3,-5,3],     type:'endpoint', conns:[3]         },
    { id:12, pos:[4,-4,1],     type:'endpoint', conns:[3]         },
    { id:13, pos:[-4,5,2],     type:'endpoint', conns:[4]         },
    { id:14, pos:[2,3,-6],     type:'endpoint', conns:[5]         },
    { id:15, pos:[0,4,-5],     type:'threat',   conns:[5]         },
  ], [])

  return (
    <>
      <PerspectiveCamera makeDefault position={[0,4,12]} fov={52} />
      <ambientLight intensity={0.2} />
      <pointLight position={[0,0,0]} color="#ffffff" intensity={2.5} distance={18} />
      <pointLight position={[6,6,6]} color="#ccccdd" intensity={1.2} distance={24} />
      <Connections nodes={nodes} />
      {nodes.map(n => <NetNode key={n.id} node={n} onHov={setHov} />)}
      <OrbitControls enableZoom autoRotate autoRotateSpeed={0.4} enablePan={false} maxDistance={22} minDistance={5} />
    </>
  )
}

export default function FlareNetGraph() {
  return (
    <Canvas gl={{ antialias:true, alpha:true }} style={{ background:'transparent' }}>
      <Scene />
    </Canvas>
  )
}
