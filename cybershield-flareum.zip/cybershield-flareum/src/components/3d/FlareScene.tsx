'use client'
import { useRef, useMemo, useEffect, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Float, PerspectiveCamera, Grid } from '@react-three/drei'
import * as THREE from 'three'

/* ─── Floating geometric cluster ─── */
function GeoCluster({ mouse }: { mouse: { x: number; y: number } }) {
  const g = useRef<THREE.Group>(null)

  useFrame((s) => {
    if (!g.current) return
    g.current.rotation.y += (mouse.x * 0.18 - g.current.rotation.y) * 0.04
    g.current.rotation.x += (-mouse.y * 0.10 - g.current.rotation.x) * 0.04
    g.current.position.y = Math.sin(s.clock.elapsedTime * 0.25) * 0.18
  })

  return (
    <group ref={g}>
      {/* Central icosahedron */}
      <Float speed={1.2} rotationIntensity={0.2} floatIntensity={0.15}>
        <mesh>
          <icosahedronGeometry args={[1.1, 1]} />
          <meshStandardMaterial color="#e8e8ea" metalness={0.9} roughness={0.08}
            transparent opacity={0.92} />
        </mesh>
        {/* Wireframe shell */}
        <mesh>
          <icosahedronGeometry args={[1.22, 1]} />
          <meshStandardMaterial color="#ffffff" wireframe transparent opacity={0.06} />
        </mesh>
      </Float>

      {/* Orbit torus 1 */}
      <mesh rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[2.1, 0.007, 6, 160]} />
        <meshStandardMaterial color="#fff" transparent opacity={0.12} />
      </mesh>

      {/* Orbit torus 2 — tilted */}
      <mesh rotation={[Math.PI/4, 0.6, 0]}>
        <torusGeometry args={[2.6, 0.005, 6, 160]} />
        <meshStandardMaterial color="#fff" transparent opacity={0.07} />
      </mesh>

      {/* Orbit torus 3 */}
      <mesh rotation={[-Math.PI/5, 1.2, 0]}>
        <torusGeometry args={[3.0, 0.004, 6, 160]} />
        <meshStandardMaterial color="#fff" transparent opacity={0.05} />
      </mesh>

      {/* Satellite cubes */}
      {useMemo(() =>
        Array.from({ length: 9 }, (_, i) => {
          const a = (i / 9) * Math.PI * 2
          const r = 2.05 + Math.sin(i * 1.3) * 0.15
          return (
            <mesh key={i} position={[Math.cos(a)*r, Math.sin(i)*0.4, Math.sin(a)*r]}>
              <boxGeometry args={[0.07, 0.07, 0.07]} />
              <meshStandardMaterial color="#fff" emissive="#fff" emissiveIntensity={0.5}
                metalness={1} roughness={0.1} />
            </mesh>
          )
        }), [])}
    </group>
  )
}

/* ─── Drifting particles ─── */
function DriftParticles() {
  const ref = useRef<THREE.Points>(null)
  const count = 1800
  const { positions, speeds } = useMemo(() => {
    const pos = new Float32Array(count * 3)
    const spd = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const r = 2 + Math.random() * 9
      const theta = Math.random() * Math.PI * 2
      const phi   = Math.acos(2 * Math.random() - 1)
      pos[i*3]   = r * Math.sin(phi) * Math.cos(theta)
      pos[i*3+1] = (Math.random() - 0.5) * 10
      pos[i*3+2] = r * Math.sin(phi) * Math.sin(theta)
      spd[i] = 0.003 + Math.random() * 0.009
    }
    return { positions: pos, speeds: spd }
  }, [])

  useFrame((s) => {
    if (!ref.current) return
    const p = ref.current.geometry.attributes.position.array as Float32Array
    for (let i = 0; i < count; i++) {
      p[i*3+1] += speeds[i]
      if (p[i*3+1] > 5) p[i*3+1] = -5
    }
    ref.current.geometry.attributes.position.needsUpdate = true
    ref.current.rotation.y = s.clock.elapsedTime * 0.012
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#ffffff" size={0.032} transparent opacity={0.28} sizeAttenuation />
    </points>
  )
}

/* ─── Ground grid ─── */
function FloorGrid() {
  const { pointer } = useThree()
  const ref = useRef<THREE.GridHelper>(null)
  useFrame(() => {
    if (ref.current) {
      ref.current.position.x += (pointer.x * 1.5 - ref.current.position.x) * 0.05
      ref.current.position.z += (pointer.y * 1.5 - ref.current.position.z) * 0.05
    }
  })
  return (
    <gridHelper ref={ref}
      args={[28, 32, '#333336', '#222224']}
      position={[0, -4, 0]}
    />
  )
}

/* ─── Thin connecting lines ─── */
function DataLines() {
  const g = useRef<THREE.Group>(null)
  const lines = useMemo(() => {
    return Array.from({ length: 20 }, () => {
      const a1 = Math.random() * Math.PI * 2
      const a2 = Math.random() * Math.PI * 2
      const r  = 2.2 + Math.random() * 1.8
      return {
        pts: [
          new THREE.Vector3(Math.cos(a1)*r, (Math.random()-0.5)*4, Math.sin(a1)*r),
          new THREE.Vector3(Math.cos(a2)*r, (Math.random()-0.5)*4, Math.sin(a2)*r),
        ]
      }
    })
  }, [])

  useFrame((s) => {
    g.current?.children.forEach((c, i) => {
      const m = (c as THREE.Line).material as THREE.LineBasicMaterial
      if (m) m.opacity = 0.04 + Math.sin(s.clock.elapsedTime*1.2 + i*0.7)*0.04
    })
  })

  return (
    <group ref={g}>
      {lines.map((l, i) => {
        const geo = new THREE.BufferGeometry().setFromPoints(l.pts)
        return (
          <line key={i} geometry={geo}>
            <lineBasicMaterial color="#ffffff" transparent opacity={0.07} />
          </line>
        )
      })}
    </group>
  )
}

/* ─── Scene wrapper ─── */
function Scene({ mouse }: { mouse: { x:number; y:number } }) {
  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0.8, 7.5]} fov={46} />
      <ambientLight intensity={0.18} />
      <directionalLight position={[4, 8, 4]}  intensity={1.8} color="#ffffff" />
      <directionalLight position={[-6, 3, -4]} intensity={0.6} color="#ccccdd" />
      <pointLight position={[0, 3, 0]} intensity={1.4} color="#ffffff" distance={12} />
      <GeoCluster mouse={mouse} />
      <DriftParticles />
      <DataLines />
      <FloorGrid />
    </>
  )
}

export default function FlareScene() {
  const [mouse, setMouse] = useState({ x: 0, y: 0 })
  useEffect(() => {
    const h = (e: MouseEvent) => setMouse({
      x: (e.clientX / window.innerWidth)  * 2 - 1,
      y: (e.clientY / window.innerHeight) * 2 - 1,
    })
    window.addEventListener('mousemove', h)
    return () => window.removeEventListener('mousemove', h)
  }, [])

  return (
    <Canvas gl={{ antialias: true, alpha: true }} style={{ background: 'transparent' }}>
      <Scene mouse={mouse} />
    </Canvas>
  )
}
