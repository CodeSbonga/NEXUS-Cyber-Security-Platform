'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'

const LINKS = [
  { href: '/',         label: 'Home'    },
  { href: '/nexus',    label: 'Nexus'   },
  { href: '/shield',   label: 'Shield'  },
  { href: '/threats',  label: 'Threats' },
  { href: '/analytics',label: 'Analytics' },
]

export default function FlareNav() {
  const path = usePathname()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const s = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', s)
    return () => window.removeEventListener('scroll', s)
  }, [])

  return (
    <motion.header
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.22,1,0.36,1] }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? 'glass border-b border-f-border' : ''
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10 h-[60px] flex items-center justify-between">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="w-5 h-5 relative flex-shrink-0">
            <div className="absolute inset-0 border border-white/30 rotate-45 group-hover:rotate-[135deg] transition-transform duration-700" />
            <div className="absolute inset-[3px] bg-white/15 rotate-45" />
          </div>
          <span className="font-syne font-700 text-[13px] tracking-tight text-f-text">
            CYBER<span className="text-white/40">SHIELD</span>
          </span>
        </Link>

        {/* Desktop links */}
        <nav className="hidden md:flex items-center gap-8">
          {LINKS.map(l => (
            <Link key={l.href} href={l.href}
              className={`f-nav-link ${path === l.href ? 'active' : ''}`}>
              {l.label}
            </Link>
          ))}
        </nav>

        {/* Right */}
        <div className="hidden md:flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="pulse-dot" />
            <span className="f-mono text-f-faint">All systems online</span>
          </div>
          <Link href="/nexus">
            <span className="f-btn-primary text-[12px] py-2 px-5">Enter Platform →</span>
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
          <div className="space-y-1.5">
            <span className={`block h-px bg-white/40 transition-all duration-300 ${open ? 'w-5 rotate-45 translate-y-2' : 'w-5'}`} />
            <span className={`block h-px bg-white/40 transition-all duration-300 ${open ? 'opacity-0 w-3' : 'w-3'}`} />
            <span className={`block h-px bg-white/40 transition-all duration-300 ${open ? 'w-5 -rotate-45 -translate-y-2' : 'w-4'}`} />
          </div>
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden glass border-t border-f-border overflow-hidden"
          >
            <div className="px-6 py-5 space-y-4">
              {LINKS.map(l => (
                <Link key={l.href} href={l.href}
                  className={`block f-nav-link py-2 ${path === l.href ? 'active' : ''}`}
                  onClick={() => setOpen(false)}>
                  {l.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  )
}
