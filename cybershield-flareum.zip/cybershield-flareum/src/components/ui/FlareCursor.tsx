'use client'
import { useEffect, useRef } from 'react'

export default function FlareCursor() {
  const dotRef  = useRef<HTMLDivElement>(null)
  const ringRef = useRef<HTMLDivElement>(null)
  let rx = 0, ry = 0

  useEffect(() => {
    const dot  = dotRef.current
    const ring = ringRef.current
    if (!dot || !ring) return

    const move = (e: MouseEvent) => {
      dot.style.left  = `${e.clientX}px`
      dot.style.top   = `${e.clientY}px`
      rx += (e.clientX - rx) * 0.14
      ry += (e.clientY - ry) * 0.14
      ring.style.left = `${rx}px`
      ring.style.top  = `${ry}px`
    }

    const onEnter = () => ring.classList.add('hover')
    const onLeave = () => ring.classList.remove('hover')

    const raf = () => {
      rx += (parseFloat(dot.style.left || '0') - rx) * 0.14
      ry += (parseFloat(dot.style.top  || '0') - ry) * 0.14
      ring.style.left = `${rx}px`
      ring.style.top  = `${ry}px`
      requestAnimationFrame(raf)
    }

    document.addEventListener('mousemove', move)
    document.querySelectorAll('a,button,[data-hover]').forEach(el => {
      el.addEventListener('mouseenter', onEnter)
      el.addEventListener('mouseleave', onLeave)
    })
    requestAnimationFrame(raf)
    return () => document.removeEventListener('mousemove', move)
  }, [])

  return (
    <>
      <div ref={dotRef}  className="f-cursor" />
      <div ref={ringRef} className="f-cursor-ring" />
    </>
  )
}
