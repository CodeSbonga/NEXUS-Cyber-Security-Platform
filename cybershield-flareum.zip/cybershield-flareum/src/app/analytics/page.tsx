'use client'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'

const FlareScene = dynamic(() => import('@/components/3d/FlareScene'), { ssr: false })

const WEEKS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
const DATA  = [42,78,55,91,67,38,84]
const MAX   = Math.max(...DATA)

const KPIS = [
  { v:'94,201', l:'Threats blocked' },
  { v:'0.03%',  l:'False positive rate' },
  { v:'0.28ms', l:'Mean detect time' },
  { v:'7',      l:'Critical incidents' },
]

export default function AnalyticsPage() {
  return (
    <main className="relative min-h-screen bg-f-bg overflow-hidden">
      <div className="fixed inset-0 z-0 opacity-30"><FlareScene /></div>
      <div className="fixed inset-0 z-[1] math-grid opacity-20 pointer-events-none" />
      <div className="fixed inset-0 z-[2] pointer-events-none"
        style={{ background:'linear-gradient(to bottom, rgba(13,13,16,0.6) 0%, rgba(13,13,16,0.3) 50%, rgba(13,13,16,0.8) 100%)' }} />

      <div className="relative z-10 pt-[76px]">
        {/* Header */}
        <div className="border-b border-f-border px-8 md:px-12 py-8">
          <motion.div initial={{ opacity:0, y:-12 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.6 }}>
            <p className="f-label mb-3">Analytics & Evolution Space</p>
            <h1 className="f-display text-f-text" style={{ fontSize:'clamp(2rem,4vw,3.6rem)' }}>
              Performance Analytics
            </h1>
          </motion.div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-f-border border-b border-f-border">
          {KPIS.map((k,i) => (
            <motion.div key={i}
              initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }}
              transition={{ delay:i*0.1, duration:0.5 }}
              className="px-8 py-8">
              <p className="f-display text-f-text" style={{ fontSize:'clamp(1.8rem,3.5vw,2.8rem)', letterSpacing:'-0.03em' }}>
                {k.v}
              </p>
              <p className="f-label mt-2">{k.l}</p>
            </motion.div>
          ))}
        </div>

        {/* Chart section */}
        <div className="px-8 md:px-12 py-10 max-w-5xl">
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:0.35, duration:0.6 }}>
            <div className="flex items-center justify-between mb-8">
              <div>
                <p className="f-label mb-2">Weekly threat activity</p>
                <p className="font-syne font-700 text-f-text" style={{ fontSize:'1.5rem', letterSpacing:'-0.03em' }}>
                  Last 7 days
                </p>
              </div>
              <div className="flex items-center gap-2 glass rounded-full px-4 py-2">
                <div className="pulse-dot" />
                <span className="f-label" style={{ color:'rgba(82,168,130,0.8)' }}>Live</span>
              </div>
            </div>

            <div className="glass rounded-2xl p-6 md:p-8">
              {/* Bar chart */}
              <div className="flex items-end gap-3 h-48">
                {DATA.map((v,i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2">
                    <motion.div
                      initial={{ height:0 }} animate={{ height:`${(v/MAX)*160}px` }}
                      transition={{ delay:0.5+i*0.1, duration:0.8, ease:'easeOut' }}
                      className="w-full rounded-t relative overflow-hidden"
                      style={{
                        background:'linear-gradient(to top, rgba(255,255,255,0.15), rgba(255,255,255,0.06))',
                        border:'1px solid rgba(255,255,255,0.1)',
                      }}>
                      <div className="absolute inset-0 bg-gradient-to-t from-white/5 to-transparent" />
                    </motion.div>
                    <span className="f-label" style={{ fontSize:'9px' }}>{WEEKS[i]}</span>
                  </div>
                ))}
              </div>
              <div className="f-divider mt-6 mb-4" />
              <div className="flex items-center justify-between">
                <span className="f-label">Peak: Thursday — 91 events</span>
                <span className="f-label text-f-sev-g">↑ 14.2% vs prior week</span>
              </div>
            </div>
          </motion.div>

          {/* Second row — two panels */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <motion.div initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }}
              transition={{ delay:0.6, duration:0.6 }}
              className="glass rounded-2xl p-6">
              <p className="f-label mb-5">Attack vectors — breakdown</p>
              {[['APT / Nation-state','38%'],['Ransomware','24%'],['Phishing','19%'],['DDoS','12%'],['Other','7%']].map(([l,p],i) => (
                <div key={i} className="mb-4">
                  <div className="flex justify-between mb-1.5">
                    <span className="f-mono text-f-dim">{l}</span>
                    <span className="f-mono text-f-text">{p}</span>
                  </div>
                  <div className="f-progress-bg">
                    <motion.div className="f-progress-fill"
                      initial={{ width:0 }} animate={{ width:p }}
                      transition={{ delay:0.8+i*0.1, duration:0.9, ease:'easeOut' }} />
                  </div>
                </div>
              ))}
            </motion.div>

            <motion.div initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }}
              transition={{ delay:0.7, duration:0.6 }}
              className="glass rounded-2xl p-6">
              <p className="f-label mb-5">Top targeted sectors</p>
              {[['Financial services','47 events'],['Critical infra','31 events'],['Healthcare','24 events'],
                ['Government','18 events'],['Technology','15 events']].map(([l,v],i) => (
                <div key={i} className="flex justify-between py-2.5 border-b border-f-border last:border-0">
                  <span className="f-mono text-f-dim">{l}</span>
                  <span className="f-mono text-f-text">{v}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </main>
  )
}
