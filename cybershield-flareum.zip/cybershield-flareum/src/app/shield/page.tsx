'use client'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'
import { useState } from 'react'

const FlareTunnel = dynamic(() => import('@/components/3d/FlareTunnel'), { ssr: false })

const MISSIONS = [
  { id:'M-001', title:'Ghost Protocol',    sub:'Infiltrate the Darknet Exchange',
    diff:'Operative', xp:2400, time:'45 min', locked:false,
    desc:'Track and neutralise a rogue AI agent distributing ransomware through encrypted channels.',
    tags:['Stealth','Network','Crypto'] },
  { id:'M-002', title:'Zero Day Hunt',     sub:'Critical Infrastructure Defence',
    diff:'Agent', xp:5100, time:'90 min', locked:false,
    desc:'A coordinated APT group targets power grid SCADA systems. Analyse, contain, eliminate.',
    tags:['ICS/SCADA','APT','Forensics'] },
  { id:'M-003', title:'Phantom Node',      sub:'AI Supply Chain Attack',
    diff:'Commander', xp:8800, time:'2h 30m', locked:true,
    desc:'A backdoor discovered in a widely-used AI model. Trace the origin, neutralise the payload.',
    tags:['AI Security','Supply Chain','Reverse Eng'] },
  { id:'M-004', title:'Iron Veil',         sub:'Nation-State Attribution',
    diff:'Commander', xp:12000, time:'3h', locked:true,
    desc:'Attribute a complex multi-vector attack to a nation-state actor using behavioural analysis.',
    tags:['OSINT','Attribution','Geopolitics'] },
]

const DIFF_COLOR: Record<string,string> = {
  Operative:'text-f-sev-g', Agent:'text-f-sev-y', Commander:'text-f-sev-r'
}

export default function ShieldPage() {
  const [sel, setSel] = useState<typeof MISSIONS[0]|null>(null)

  return (
    <main className="relative min-h-screen bg-f-bg overflow-hidden">
      <div className="fixed inset-0 z-0"><FlareTunnel /></div>
      <div className="fixed inset-0 z-[1] math-grid opacity-25 pointer-events-none" />
      <div className="fixed inset-0 z-[2] pointer-events-none"
        style={{ background:'linear-gradient(to bottom, rgba(13,13,16,0.85) 0%, rgba(13,13,16,0.4) 40%, rgba(13,13,16,0.9) 100%)' }} />

      <div className="relative z-10 pt-[76px]">
        {/* Header */}
        <div className="border-b border-f-border px-8 md:px-12 py-8 flex items-end justify-between flex-wrap gap-6">
          <motion.div initial={{ opacity:0, y:-12 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.6 }}>
            <p className="f-label mb-3">CyberShield Simulation Hub</p>
            <h1 className="f-display text-f-text" style={{ fontSize:'clamp(2rem,4vw,3.6rem)' }}>
              Mission Operations
            </h1>
          </motion.div>
          {/* Player badge */}
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:0.3 }}
            className="flex gap-4 flex-wrap">
            {[['Rank','Operative'],['XP','14,820'],['Missions','7 / 24'],['Accuracy','94.2%']].map(([l,v],i) => (
              <div key={i} className="glass rounded-lg px-4 py-3 text-center">
                <p className="f-label" style={{ fontSize:'8px', marginBottom:'4px' }}>{l}</p>
                <p className="font-syne font-700 text-f-text" style={{ fontSize:'15px', letterSpacing:'-0.02em' }}>{v}</p>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-px bg-f-border m-0 border-b border-f-border">
          {MISSIONS.map((m,i) => (
            <motion.div key={m.id}
              initial={{ opacity:0, y:24 }} animate={{ opacity:1, y:0 }}
              transition={{ delay:0.15+i*0.1, duration:0.6 }}
              onClick={() => !m.locked && setSel(m)}
              className={`relative glass p-7 corner-tl corner-br transition-all duration-300
                ${m.locked ? 'opacity-40 cursor-not-allowed' : 'cursor-none hover:bg-white/[0.03]'}`}>
              <div className="flex justify-between items-start mb-5">
                <span className="f-label">{m.id}</span>
                <span className={`f-mono font-500 ${DIFF_COLOR[m.diff]}`} style={{ fontSize:'10px' }}>
                  {m.diff}
                </span>
              </div>
              <h3 className="font-syne font-700 text-f-text mb-1"
                style={{ fontSize:'17px', letterSpacing:'-0.02em' }}>
                {m.title}
              </h3>
              <p className="f-mono text-f-faint mb-5">{m.sub}</p>
              <div className="flex flex-wrap gap-1.5 mb-6">
                {m.tags.map(t => (
                  <span key={t} className="f-mono text-f-faint glass rounded px-2 py-0.5"
                    style={{ fontSize:'9px' }}>{t}</span>
                ))}
              </div>
              <div className="f-divider mb-4" />
              <div className="flex justify-between">
                <div>
                  <p className="f-label" style={{ fontSize:'8px' }}>Reward</p>
                  <p className="f-mono text-f-sev-g">+{m.xp.toLocaleString()} XP</p>
                </div>
                <div className="text-right">
                  <p className="f-label" style={{ fontSize:'8px' }}>Duration</p>
                  <p className="f-mono text-f-dim">{m.time}</p>
                </div>
              </div>
              {m.locked && (
                <div className="absolute inset-0 flex items-center justify-center bg-f-bg/50 rounded">
                  <span className="f-label">Locked</span>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Briefing modal */}
      {sel && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-f-bg/80 backdrop-blur-xl px-6"
          onClick={() => setSel(null)}>
          <motion.div initial={{ scale:0.88, y:24 }} animate={{ scale:1, y:0 }}
            className="glass-md rounded-2xl p-8 md:p-10 max-w-md w-full relative corner-tl corner-br"
            onClick={e => e.stopPropagation()}>
            <p className="f-label mb-2">Mission briefing</p>
            <h2 className="f-display text-f-text mb-1" style={{ fontSize:'2.2rem' }}>{sel.title}</h2>
            <p className="f-mono text-f-faint mb-6">{sel.sub}</p>
            <p className="font-sans font-light text-f-dim mb-8" style={{ fontSize:'14px', lineHeight:1.7 }}>
              {sel.desc}
            </p>
            <div className="grid grid-cols-3 gap-3 mb-8">
              {[['Difficulty',sel.diff,DIFF_COLOR[sel.diff]],['Duration',sel.time,'text-f-text'],
                ['XP Reward',`+${sel.xp.toLocaleString()}`,'text-f-sev-g']].map(([l,v,c],i) => (
                <div key={i} className="glass rounded-lg p-3 text-center">
                  <p className="f-label" style={{ fontSize:'8px', marginBottom:'4px' }}>{l}</p>
                  <p className={`f-mono font-500 ${c}`}>{v}</p>
                </div>
              ))}
            </div>
            <div className="flex gap-3">
              <button className="f-btn-primary flex-1 justify-center">Initiate Mission →</button>
              <button onClick={() => setSel(null)} className="f-btn-ghost px-5">Abort</button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </main>
  )
}
