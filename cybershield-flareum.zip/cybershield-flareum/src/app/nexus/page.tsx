'use client'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'
import { useState, useEffect } from 'react'

const FlareNetGraph = dynamic(() => import('@/components/3d/FlareNetGraph'), { ssr: false })

const INSIGHTS = [
  { level: 'CRITICAL', msg: 'APT-41 lateral movement detected in Sector 7', t: '00:02' },
  { level: 'HIGH',     msg: 'Zero-day exploit attempt on firewall cluster',   t: '00:07' },
  { level: 'MEDIUM',   msg: 'Anomalous data exfil pattern — endpoint #847',  t: '00:15' },
  { level: 'LOW',      msg: 'Brute force signatures on auth gateway',         t: '00:31' },
]
const SEV_STYLE: Record<string,string> = {
  CRITICAL: 'sev-critical', HIGH: 'sev-high', MEDIUM: 'sev-medium', LOW: 'sev-low',
}
const SEV_TEXT: Record<string,string> = {
  CRITICAL: 'text-f-sev-r', HIGH: 'text-f-sev-a', MEDIUM: 'text-f-sev-y', LOW: 'text-f-sev-g',
}

const SYSTEMS = [
  { name: 'Neural Firewall',   pct: 99.7 },
  { name: 'Quantum Encrypt',   pct: 100  },
  { name: 'AI Sentinel',       pct: 98.2 },
  { name: 'Dark Web Monitor',  pct: 94.1 },
]

const THREAT_POOL = [
  { type:'APT INTRUSION',  src:'185.220.x.x',  tgt:'GATEWAY-07',    sev:'CRITICAL', st:'LIVE'        },
  { type:'RANSOMWARE',     src:'91.108.x.x',   tgt:'ENDPOINT-247',  sev:'HIGH',     st:'LIVE'        },
  { type:'SQL INJECTION',  src:'194.165.x.x',  tgt:'DB-CLUSTER-3',  sev:'HIGH',     st:'CONTAINED'   },
  { type:'PHISHING',       src:'UNKNOWN',       tgt:'MAILSERVER-01', sev:'MEDIUM',   st:'NEUTRALIZED' },
  { type:'DDoS WAVE',      src:'BOTNET',        tgt:'CDN-EDGE-12',   sev:'HIGH',     st:'CONTAINED'   },
  { type:'ZERO-DAY',       src:'45.142.x.x',   tgt:'FIREWALL-A',    sev:'CRITICAL', st:'LIVE'        },
  { type:'LATERAL MOVE',   src:'INTERNAL',      tgt:'SECTOR-7-NET',  sev:'CRITICAL', st:'LIVE'        },
]

interface ThreatRow { id:string; ts:string; type:string; src:string; tgt:string; sev:string; st:string }

export default function NexusPage() {
  const [feed, setFeed] = useState<ThreatRow[]>(() =>
    THREAT_POOL.slice(0,6).map((t,i) => ({
      ...t, id:`THR-${1000+i}`,
      ts: new Date(Date.now()-i*45000).toISOString().slice(11,19)
    }))
  )

  useEffect(() => {
    const iv = setInterval(() => {
      const t = THREAT_POOL[Math.floor(Math.random()*THREAT_POOL.length)]
      setFeed(p => [{
        ...t, id:`THR-${Math.floor(Math.random()*9000)+1000}`,
        ts: new Date().toISOString().slice(11,19),
        st: Math.random()>0.4 ? 'LIVE' : 'CONTAINED',
      }, ...p.slice(0,9)])
    }, 3400)
    return () => clearInterval(iv)
  }, [])

  return (
    <main className="relative min-h-screen bg-f-bg overflow-hidden">
      {/* 3D background */}
      <div className="fixed inset-0 z-0"><FlareNetGraph /></div>
      <div className="fixed inset-0 z-[1] math-grid-fine opacity-40 pointer-events-none" />
      <div className="fixed inset-0 z-[2] pointer-events-none"
        style={{ background:'linear-gradient(to bottom, rgba(13,13,16,0.7) 0%, transparent 40%, rgba(13,13,16,0.8) 100%)' }} />

      <div className="relative z-10 pt-[76px]">
        {/* Page header */}
        <div className="border-b border-f-border px-8 md:px-12 py-8">
          <motion.div initial={{ opacity:0, y:-12 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.6 }}>
            <p className="f-label mb-3">Nexus Intelligence Core — Sector Alpha</p>
            <h1 className="f-display text-f-text" style={{ fontSize:'clamp(2rem,4vw,3.6rem)' }}>
              Threat Command
            </h1>
          </motion.div>
        </div>

        {/* Stats row */}
        <div className="border-b border-f-border grid grid-cols-3 md:grid-cols-6 divide-x divide-f-border">
          {[
            { v:'1,847',  l:'Active threats'    },
            { v:'94,201', l:'Blocked today'      },
            { v:'847',    l:'Nodes monitored'    },
            { v:'99.7%',  l:'AI uptime'          },
            { v:'<0.3ms', l:'Response time'      },
            { v:'23',     l:'Threat actors tracked'},
          ].map((s,i) => (
            <motion.div key={i}
              initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }}
              transition={{ delay:0.1+i*0.07, duration:0.5 }}
              className="px-5 py-5">
              <p className="font-syne font-700 text-f-text" style={{ fontSize:'1.35rem', letterSpacing:'-0.03em' }}>
                {s.v}
              </p>
              <p className="f-label mt-1" style={{ fontSize:'9px' }}>{s.l}</p>
            </motion.div>
          ))}
        </div>

        {/* Main 3-column grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 border-b border-f-border">

          {/* Threat feed — 2 cols */}
          <div className="lg:col-span-2 border-r border-f-border">
            <div className="px-6 py-4 border-b border-f-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="pulse-dot" />
                <span className="f-label">Live threat feed</span>
              </div>
              <span className="f-mono text-f-faint">{feed.length} events</span>
            </div>

            {/* Column headers */}
            <div className="grid grid-cols-6 gap-2 px-6 py-2 border-b border-f-border">
              {['Time','Type','Source','Target','Severity','Status'].map(h => (
                <span key={h} className="f-label" style={{ fontSize:'8px' }}>{h}</span>
              ))}
            </div>

            <div className="divide-y divide-f-border max-h-96 overflow-y-auto">
              {feed.map((row,i) => (
                <motion.div key={row.id+i}
                  initial={{ opacity:0, backgroundColor:'rgba(255,255,255,0.04)' }}
                  animate={{ opacity:1, backgroundColor:'rgba(0,0,0,0)' }}
                  transition={{ duration:0.5 }}
                  className={`grid grid-cols-6 gap-2 px-6 py-3 hover:bg-white/[0.02] transition-colors
                    ${row.st==='LIVE' ? 'border-l-2 border-f-sev-r/40' : 'border-l-2 border-transparent'}`}>
                  <span className="f-mono text-f-faint">{row.ts}</span>
                  <span className="f-mono text-f-text/70 truncate">{row.type}</span>
                  <span className="f-mono text-f-faint truncate">{row.src}</span>
                  <span className="f-mono text-f-dim truncate">{row.tgt}</span>
                  <div className="flex items-center gap-1.5">
                    <div className={`w-1.5 h-1.5 rounded-full ${SEV_STYLE[row.sev]} ${row.sev==='CRITICAL'?'animate-pulse':''}`} />
                    <span className={`f-mono ${SEV_TEXT[row.sev] || 'text-f-dim'}`}>{row.sev}</span>
                  </div>
                  <span className={`f-mono ${row.st==='LIVE'?'text-f-sev-r animate-pulse':row.st==='CONTAINED'?'text-f-sev-y':'text-f-sev-g'}`}>
                    {row.st}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right sidebar */}
          <div className="divide-y divide-f-border">
            {/* AI Analysis */}
            <div className="p-6">
              <p className="f-label mb-4">AI threat analysis</p>
              <div className="space-y-3">
                {INSIGHTS.map((item,i) => (
                  <motion.div key={i}
                    initial={{ opacity:0, x:12 }} animate={{ opacity:1, x:0 }}
                    transition={{ delay:0.4+i*0.1, duration:0.5 }}
                    className="p-3 glass rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <div className={`w-1.5 h-1.5 rounded-full ${SEV_STYLE[item.level]}`} />
                        <span className={`f-mono font-500 ${SEV_TEXT[item.level]}`}>{item.level}</span>
                      </div>
                      <span className="f-mono text-f-faint">{item.t}s ago</span>
                    </div>
                    <p className="f-mono text-f-dim leading-relaxed">{item.msg}</p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* System integrity */}
            <div className="p-6">
              <p className="f-label mb-4">System integrity</p>
              <div className="space-y-4">
                {SYSTEMS.map((s,i) => (
                  <div key={i}>
                    <div className="flex justify-between mb-1.5">
                      <span className="f-mono text-f-dim">{s.name}</span>
                      <span className="f-mono text-f-sev-g">{s.pct}%</span>
                    </div>
                    <div className="f-progress-bg">
                      <motion.div className="f-progress-fill"
                        initial={{ width:0 }}
                        animate={{ width:`${s.pct}%` }}
                        transition={{ delay:0.6+i*0.1, duration:1, ease:'easeOut' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
