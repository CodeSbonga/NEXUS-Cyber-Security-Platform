'use client'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'

const FlareGlobe = dynamic(() => import('@/components/3d/FlareGlobe'), { ssr: false })

const ATTACKS = [
  { from:'Beijing',   to:'New York',  type:'APT',          sev:'CRITICAL' },
  { from:'Moscow',    to:'London',    type:'Ransomware',   sev:'HIGH'     },
  { from:'Tehran',    to:'Tel Aviv',  type:'DDoS',         sev:'HIGH'     },
  { from:'Pyongyang', to:'Seoul',     type:'Spear-Phish',  sev:'MEDIUM'   },
  { from:'Brazil',    to:'Miami',     type:'Botnet',       sev:'LOW'      },
  { from:'Lagos',     to:'London',    type:'Fraud',        sev:'LOW'      },
]
const SEV: Record<string,string> = {
  CRITICAL:'text-f-sev-r', HIGH:'text-f-sev-a', MEDIUM:'text-f-sev-y', LOW:'text-f-sev-g'
}
const SDOT: Record<string,string> = {
  CRITICAL:'sev-critical', HIGH:'sev-high', MEDIUM:'sev-medium', LOW:'sev-low'
}

export default function ThreatsPage() {
  return (
    <main className="relative min-h-screen bg-f-bg overflow-hidden">
      <div className="fixed inset-0 z-0"><FlareGlobe /></div>
      <div className="fixed inset-0 z-[1] math-grid-fine opacity-20 pointer-events-none" />
      <div className="fixed inset-0 z-[2] pointer-events-none"
        style={{ background:'radial-gradient(ellipse 90% 80% at 50% 50%, transparent 20%, rgba(13,13,16,0.7) 80%)' }} />
      <div className="fixed inset-0 z-[3] pointer-events-none"
        style={{ background:'linear-gradient(to right, rgba(13,13,16,0.75) 0%, transparent 30%, transparent 70%, rgba(13,13,16,0.75) 100%)' }} />

      {/* Top label */}
      <motion.div initial={{ opacity:0, y:-10 }} animate={{ opacity:1, y:0 }}
        className="fixed top-[76px] left-1/2 -translate-x-1/2 z-10 glass rounded-full px-5 py-2">
        <span className="f-label">Global Cyber Threat Visualisation Chamber</span>
      </motion.div>

      {/* Left panel */}
      <motion.div initial={{ opacity:0, x:-28 }} animate={{ opacity:1, x:0 }}
        transition={{ delay:0.4 }}
        className="fixed left-6 top-32 z-10 w-64 space-y-3">

        <div className="glass rounded-xl p-5">
          <p className="f-label mb-4">Global overview</p>
          <div className="space-y-2.5">
            {[['Active attacks','1,847','text-f-sev-r'],
              ['Blocked today','94,201','text-f-text'],
              ['Countries at risk','47','text-f-sev-a']].map(([l,v,c],i) => (
              <div key={i} className="flex justify-between items-center">
                <span className="f-mono text-f-faint">{l}</span>
                <span className={`f-mono font-500 ${c} ${l==='Active attacks'?'animate-pulse':''}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-xl p-5">
          <p className="f-label mb-4">Live attack streams</p>
          <div className="space-y-3">
            {ATTACKS.map((a,i) => (
              <motion.div key={i}
                initial={{ opacity:0, x:-12 }} animate={{ opacity:1, x:0 }}
                transition={{ delay:0.7+i*0.1 }}
                className="flex items-center gap-2">
                <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${SDOT[a.sev]} ${a.sev==='CRITICAL'?'animate-pulse':''}`} />
                <span className="f-mono text-f-faint flex-1 truncate" style={{ fontSize:'10px' }}>
                  {a.from} → {a.to}
                </span>
                <span className={`f-mono ${SEV[a.sev]}`} style={{ fontSize:'9px' }}>{a.type}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Bottom controls */}
      <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }}
        transition={{ delay:0.5 }}
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-10 glass rounded-full px-7 py-3 flex items-center gap-6">
        {[['Rotate','Drag'],['Zoom','Scroll'],['Inspect','Click node']].map(([l,a],i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="f-label" style={{ fontSize:'8px' }}>{l}</span>
            <span className="f-mono text-f-faint glass rounded px-2 py-0.5" style={{ fontSize:'9px' }}>{a}</span>
          </div>
        ))}
      </motion.div>
    </main>
  )
}
