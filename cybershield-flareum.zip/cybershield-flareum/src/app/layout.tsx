import type { Metadata } from 'next'
import '../styles/globals.css'
import FlareCursor from '@/components/ui/FlareCursor'
import FlareNav from '@/components/ui/FlareNav'
import FlareTransition from '@/components/ui/FlareTransition'

export const metadata: Metadata = {
  title: 'CyberShield + NEXUS — AI Cyber Defense',
  description: 'Next-generation AI-powered cybersecurity intelligence platform',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="grain">
        <FlareCursor />
        <FlareNav />
        <FlareTransition>{children}</FlareTransition>
      </body>
    </html>
  )
}
