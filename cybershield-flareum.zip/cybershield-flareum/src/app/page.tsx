'use client'

import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useState, useEffect } from 'react'

const FlareScene = dynamic(() => import('@/components/3d/FlareScene'), { ssr: false })

const STATS = [
  { val: '99.7%',    label: 'Detection accuracy' },
  { val: '<0.3ms',   label: 'Response latency'   },
  { val: '847M+',    label: 'Attacks neutralised' },
  { val: '24 / 7',   label: 'AI sentinel uptime'  },
]

const FEATURES = [
  { n: '01', title: 'NEXUS Intelligence',
    body: 'Real-time neural network analysis across 847 monitored nodes, powered by next-generation adversarial AI.' },
  { n: '02', title: 'Simulation Hub',
    body: 'Immersive mission-based training. Investigate attacks, defend infrastructure, hunt APT threat actors.' },
  { n: '03', title: 'Threat Visualisation',
    body: 'Global attack surface rendered as a 3D intelligence chamber. Every vector, every origin, live.' },
  { n: '04', title: 'Predictive Defence',
    body: 'Autonomous countermeasures that anticipate zero-days before they breach your perimeter.' },
]

export default function HomePage() {
  const [count, setCount] = useState(1847)
  useEffect(() => {
    const t = setInterval(() => setCount(p => p + Math.floor(Math.random() * 3)), 2200)
    return () => clearInterval(t)
  }, [])

  return (
    <main className="relative bg-f-bg min-h-screen overflow-hidden">

      {/* ── 3D scene fills viewport ── */}
      <div className="fixed inset-0 z-0">
        <FlareScene />
      </div>

      {/* ── Math grid ── */}
      <div className="fixed inset-0 z-[1] math-grid pointer-events-none" />

      {/* ── Radial vignette ── */}
      <div className="fixed inset-0 z-[2] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse 80% 70% at 50% 50%, transparent 30%, #0d0d10 100%)' }} />

      {/* ══════════════════════════════════════
          HERO
      ══════════════════════════════════════ */}
      <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 pb-16 pt-24">

        {/* Live badge */}
        <motion.div initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }}
          transition={{ delay:0.3, duration:0.7 }}
          className="flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-10">
          <div className="pulse-dot" />
          <span className="f-label" style={{ color: 'rgba(82,168,130,0.9)' }}>
            {count.toLocaleString()} active threats detected
          </span>
        </motion.div>

        {/* Giant display heading — Flareum style */}
        <motion.h1 initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }}
          transition={{ delay:0.45, duration:0.9, ease:[0.22,1,0.36,1] }}
          className="f-display text-center text-f-text"
          style={{ fontSize: 'clamp(3.8rem, 10vw, 9.5rem)', maxWidth: '18ch' }}>
          Secure your<br />
          <span style={{ color: 'rgba(242,242,244,0.35)', fontStyle:'italic', fontWeight:700 }}>
            digital frontier.
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p initial={{ opacity:0, y:18 }} animate={{ opacity:1, y:0 }}
          transition={{ delay:0.65, duration:0.7 }}
          className="mt-8 text-center font-sans font-light text-f-dim"
          style={{ fontSize:'17px', maxWidth:'42ch', lineHeight:1.65 }}>
          Real-time threat intelligence powered by adaptive AI.
          Monitor, detect, and neutralise with next-generation precision.
        </motion.p>

        {/* CTAs */}
        <motion.div initial={{ opacity:0, y:14 }} animate={{ opacity:1, y:0 }}
          transition={{ delay:0.82, duration:0.6 }}
          className="flex flex-col sm:flex-row gap-3 mt-10">
          <Link href="/nexus"><span className="f-btn-primary">Enter NEXUS →</span></Link>
          <Link href="/shield"><span className="f-btn-ghost">View Simulations</span></Link>
        </motion.div>

        {/* Scroll cue */}
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}
          transition={{ delay:2, duration:1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="f-label" style={{ fontSize:'9px' }}>Scroll</span>
          <motion.div animate={{ y:[0,6,0] }} transition={{ duration:1.6, repeat:Infinity, ease:'easeInOut' }}
            className="w-px h-8 bg-gradient-to-b from-white/20 to-transparent" />
        </motion.div>
      </section>

      {/* ══════════════════════════════════════
          STATS STRIP
      ══════════════════════════════════════ */}
      <section className="relative z-10 border-t border-f-border">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 divide-x divide-f-border">
          {STATS.map((s, i) => (
            <motion.div key={i}
              initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }}
              viewport={{ once:true }} transition={{ delay:i*0.1, duration:0.6 }}
              className="px-8 py-10">
              <p className="f-display text-f-text" style={{ fontSize:'clamp(2rem,4vw,3.2rem)', letterSpacing:'-0.03em' }}>
                {s.val}
              </p>
              <p className="f-label mt-2">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ══════════════════════════════════════
          FEATURES GRID
      ══════════════════════════════════════ */}
      <section className="relative z-10 border-t border-f-border px-6 py-24 max-w-6xl mx-auto">
        <motion.div initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }}
          viewport={{ once:true }} transition={{ duration:0.6 }}
          className="mb-16">
          <p className="f-label mb-4">Platform capabilities</p>
          <h2 className="f-display text-f-text" style={{ fontSize:'clamp(2.5rem,5vw,5rem)', maxWidth:'16ch' }}>
            Every attack surface. Covered.
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-f-border">
          {FEATURES.map((f, i) => (
            <motion.div key={i}
              initial={{ opacity:0 }} whileInView={{ opacity:1 }}
              viewport={{ once:true }} transition={{ delay:i*0.1, duration:0.6 }}
              className="relative glass p-8 md:p-10 corner-tl corner-br group hover:bg-white/[0.035] transition-colors duration-300 cursor-none">
              <span className="f-label block mb-6" style={{ fontSize:'9px' }}>{f.n}</span>
              <h3 className="font-syne font-700 text-f-text mb-3" style={{ fontSize:'18px', letterSpacing:'-0.02em' }}>
                {f.title}
              </h3>
              <p className="font-sans font-light text-f-dim" style={{ fontSize:'14px', lineHeight:1.7 }}>
                {f.body}
              </p>
              <div className="f-divider mt-8" />
              <div className="mt-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="f-label" style={{ fontSize:'9px', color:'var(--text-faint)' }}>Explore</span>
                <span className="text-f-faint text-xs">→</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ══════════════════════════════════════
          CTA BANNER
      ══════════════════════════════════════ */}
      <section className="relative z-10 border-t border-f-border px-6 py-24">
        <motion.div initial={{ opacity:0, y:24 }} whileInView={{ opacity:1, y:0 }}
          viewport={{ once:true }} transition={{ duration:0.7 }}
          className="max-w-4xl mx-auto text-center">
          <h2 className="f-display text-f-text mb-6"
            style={{ fontSize:'clamp(2.5rem,6vw,6rem)' }}>
            Intelligence that never sleeps.
          </h2>
          <p className="font-sans font-light text-f-dim mx-auto mb-10"
            style={{ fontSize:'16px', maxWidth:'38ch', lineHeight:1.7 }}>
            CyberShield + NEXUS operates as your autonomous AI guardian — learning, adapting, and neutralising threats 24/7.
          </p>
          <Link href="/nexus">
            <span className="f-btn-primary" style={{ fontSize:'14px', padding:'13px 36px' }}>
              Access the Platform →
            </span>
          </Link>
        </motion.div>
      </section>

      {/* Footer strip */}
      <footer className="relative z-10 border-t border-f-border px-6 md:px-10 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <span className="f-label" style={{ fontSize:'9px' }}>© 2026 CyberShield + NEXUS. All rights reserved.</span>
          <div className="flex items-center gap-2">
            <div className="pulse-dot" />
            <span className="f-label" style={{ fontSize:'9px', color:'rgba(82,168,130,0.7)' }}>
              System nominal — AI sentinel active
            </span>
          </div>
        </div>
      </footer>
    </main>
  )
}
